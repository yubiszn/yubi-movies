import 'dart:convert';
import 'package:http/http.dart' as http;
import 'movie.dart';

class HttpHelper {
  final String apiKey = '4872e09'; // OMDb API key
  final String baseUrl = 'http://www.omdbapi.com/';
  
  Future<List<Movie>> findMovies(String title) async {
    if (title.isEmpty) {
      print('Error: Search query is empty.');
      return [];
    }

    final String url = '$baseUrl?s=$title&apikey=$apiKey';
    final http.Response response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);

      if (jsonResponse['Response'] == 'True') {
        final moviesList = jsonResponse['Search'] as List;
        return moviesList.map((json) => Movie.fromJson(json)).toList();
      } else {
        print('Error finding movies: ${jsonResponse['Error']}');
        return [];
      }
    } else {
      print('HTTP request failed with status: ${response.statusCode}');
      return [];
    }
  }

  Future<List<Movie>> findFeaturedMovies() async {
    // List of popular movie titles
    final titles = [
      'Pulp Fiction', 'The Batman', 'Star Wars: Episode V', 'Rocky'
    ];
    
    final random = (titles..shuffle()).take(5); 
    final List<Movie> movies = [];
    
    for (var title in random) {
      final movieList = await findMovies(title);
      if (movieList.isNotEmpty) {
        movies.add(movieList.first); 
      }
    }
    
    return movies;
  }

  Future<Movie?> getMovieDetails(String imdbID) async {
    final String url = '$baseUrl?i=$imdbID&apikey=$apiKey';
    final http.Response response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['Response'] == 'True') {
        return Movie.fromJson(jsonResponse);
      } else {
        print('Error finding movie details: ${jsonResponse['Error']}');
        return null;
      }
    } else {
      print('HTTP request failed with status: ${response.statusCode}');
      return null;
    }
  }
}
