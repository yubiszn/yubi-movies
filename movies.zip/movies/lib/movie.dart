class Movie {
  final String title;
  final String year;
  final String imdbID;
  final String type;
  final String poster;
  final String? plot; 
  final String? rated;
  final String? released;
  final String? runtime;
  final String? genre;
  final String? director;
  final String? writer;
  final String? actors;
  final String? language;
  final String? country;
  final String? awards;
  final String? metascore;
  final String? imdbRating;
  final String? imdbVotes;
  final String? boxOffice;

  Movie({
    required this.title,
    required this.year,
    required this.imdbID,
    required this.type,
    required this.poster,
    this.plot,
    this.rated,
    this.released,
    this.runtime,
    this.genre,
    this.director,
    this.writer,
    this.actors,
    this.language,
    this.country,
    this.awards,
    this.metascore,
    this.imdbRating,
    this.imdbVotes,
    this.boxOffice,
  });

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      title: json['Title'],
      year: json['Year'],
      imdbID: json['imdbID'],
      type: json['Type'],
      poster: json['Poster'],
      plot: json['Plot'], // Plot can be null
      rated: json['Rated'],
      released: json['Released'],
      runtime: json['Runtime'],
      genre: json['Genre'],
      director: json['Director'],
      writer: json['Writer'],
      actors: json['Actors'],
      language: json['Language'],
      country: json['Country'],
      awards: json['Awards'],
      metascore: json['Metascore'],
      imdbRating: json['imdbRating'],
      imdbVotes: json['imdbVotes'],
      boxOffice: json['BoxOffice'],
    );
  }
}
