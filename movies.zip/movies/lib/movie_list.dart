import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'http_helper.dart';
import 'movie.dart';

class MovieList extends StatefulWidget {
  @override
  _MovieListState createState() => _MovieListState();
}

class _MovieListState extends State<MovieList> {
  HttpHelper helper = HttpHelper();
  List<Movie> featuredMovies = [];
  Map<String, List<Movie>> genreMovies = {};
  List<Movie> searchResults = [];
  final String defaultImage = 'https://images.freeimages.com/images/large-previews/5eb/movie-clapboard-1184339.jpg';
  Icon visibleIcon = Icon(Icons.search);
  Widget searchBar = Text('Yubi');

  @override
  void initState() {
    super.initState();
    initialize();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: searchBar,
        actions: <Widget>[
          IconButton(
            icon: visibleIcon,
            onPressed: () {
              setState(() {
                if (this.visibleIcon.icon == Icons.search) {
                  this.visibleIcon = Icon(Icons.cancel);
                  this.searchBar = TextField(
                    textInputAction: TextInputAction.search,
                    onSubmitted: (String text) {
                      search(text);
                    },
                    style: TextStyle(
                      color: Color.fromARGB(255, 0, 0, 0),
                      fontSize: 20.0,
                    ),
                  );
                } else {
                  this.visibleIcon = Icon(Icons.search);
                  this.searchBar = Text('Movies');
                  clearSearchResults();
                }
              });
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            searchResults.isNotEmpty
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Text(
                          'Search Results',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 255, 255, 255)),
                        ),
                      ),
                      SizedBox(height: 10),
                      Container(
                        height: 200,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: searchResults.length,
                          itemBuilder: (context, index) {
                            final movie = searchResults[index];
                            final imageUrl = movie.poster.isNotEmpty ? movie.poster : defaultImage;
                            return GestureDetector(
                              onTap: () async {
                                final details = await helper.getMovieDetails(movie.imdbID);
                                if (details != null) {
                                  Navigator.pushNamed(
                                    context,
                                    '/movieDetail',
                                    arguments: details,
                                  );
                                }
                              },
                              child: Container(
                                width: 160,
                                margin: EdgeInsets.symmetric(horizontal: 8.0),
                                child: Image.network(imageUrl, fit: BoxFit.cover),
                              ),
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 20),
                    ],
                  )
                : featuredMovies.isNotEmpty
                    ? CarouselSlider.builder(
                        itemCount: featuredMovies.length,
                        itemBuilder: (context, index, realIndex) {
                          final movie = featuredMovies[index];
                          final imageUrl = movie.poster.isNotEmpty ? movie.poster : defaultImage;
                          return GestureDetector(
                            onTap: () async {
                              final details = await helper.getMovieDetails(movie.imdbID);
                              if (details != null) {
                                Navigator.pushNamed(
                                  context,
                                  '/movieDetail',
                                  arguments: details,
                                );
                              }
                            },
                            child: Container(
                              width: double.infinity,
                              child: Image.network(imageUrl, fit: BoxFit.cover),
                            ),
                          );
                        },
                        options: CarouselOptions(
                          height: 550.0,
                          autoPlay: true,
                          aspectRatio: 16/9,
                          viewportFraction: 1.0,
                        ),
                      )
                    : Center(child: Text('No featured movies available')),
            SizedBox(height: 20),
            ...genreMovies.entries.map((entry) {
              final genre = entry.key;
              final movies = entry.value;
              return movies.isNotEmpty
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Text(
                            genre,
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 255, 255, 255)),
                          ),
                        ),
                        SizedBox(height: 10),
                        Container(
                          height: 200,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: movies.length,
                            itemBuilder: (context, index) {
                              final movie = movies[index];
                              final imageUrl = movie.poster.isNotEmpty ? movie.poster : defaultImage;
                              return GestureDetector(
                                onTap: () async {
                                  final details = await helper.getMovieDetails(movie.imdbID);
                                  if (details != null) {
                                    Navigator.pushNamed(
                                      context,
                                      '/movieDetail',
                                      arguments: details,
                                    );
                                  }
                                },
                                child: Container(
                                  width: 120,
                                  margin: EdgeInsets.symmetric(horizontal: 8.0),
                                  child: Image.network(imageUrl, fit: BoxFit.cover),
                                ),
                              );
                            },
                          ),
                        ),
                        SizedBox(height: 20),
                      ],
                    )
                  : SizedBox.shrink();
            }).toList(),
          ],
        ),
      ),
    );
  }

  Future<void> search(String text) async {
    final result = await helper.findMovies(text);
    setState(() {
      searchResults = result;
    });
  }

  void clearSearchResults() {
    setState(() {
      searchResults = [];
    });
  }

  Future<void> initialize() async {
    final featured = await helper.findFeaturedMovies();
    setState(() {
      featuredMovies = featured;
    });

    final genres = ['Marvel', 'Disney', 'Horror', 'Action'];
    for (var genre in genres) {
      final result = await helper.findMovies(genre);
      setState(() {
        genreMovies[genre] = result;
      });
    }
  }
}
